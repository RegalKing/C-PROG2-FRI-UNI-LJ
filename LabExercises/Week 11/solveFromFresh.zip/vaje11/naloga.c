
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "naloga.h"

int vsotaI(Vozlisce* zacetek) {
    // popravite / dopolnite ...
    return -999;
}

int vsotaR(Vozlisce* zacetek) {
    // popravite / dopolnite ...
    return -999;
}

Vozlisce* vstaviUrejenoI(Vozlisce* zacetek, int element) {
    // popravite / dopolnite ...
    return NULL;
}

Vozlisce* vstaviUrejenoR(Vozlisce* zacetek, int element) {
    // popravite / dopolnite ...
    return NULL;
}

int main() {
    // koda za ro"cno testiranje (po "zelji)

    return 0;
}
