
#include <stdio.h>
#include <stdlib.h>

#include "naloga.h"

int vsota(int* zac, int* kon) {
    // popravite / dopolnite ...
    return -1;
}

void indeksInKazalec(int* t, int* indeks, int** kazalec) {
    // dopolnite ...
}

void frekvenceCrk(char* niz, int** frekvence) {
    // dopolnite ...
}

#ifndef test

int main() {
    // koda za ro"cno testiranje (po "zelji)

    return 0;
}

#endif
