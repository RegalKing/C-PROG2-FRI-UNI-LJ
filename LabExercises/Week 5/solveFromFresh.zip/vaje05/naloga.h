
#ifndef _NALOGA_H
#define _NALOGA_H

int vsota(int* zac, int* kon);
void indeksInKazalec(int* t, int* indeks, int** kazalec);
void frekvenceCrk(char* niz, int** frekvence);

#endif
