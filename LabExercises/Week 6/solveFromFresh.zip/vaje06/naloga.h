
#ifndef _NALOGA_H
#define _NALOGA_H

int steviloZnakov(char* besedilo, char znak);
char* kopirajDoZnaka(char* niz, char znak);
char** razcleni(char* besedilo, char locilo, int* stOdsekov);

#endif
