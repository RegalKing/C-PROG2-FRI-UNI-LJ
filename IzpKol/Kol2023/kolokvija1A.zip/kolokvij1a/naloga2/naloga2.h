
#ifndef _NALOGA2_H
#define _NALOGA2_H

char** poStolpcih(char** nizi, int stVhodnih, int* stIzhodnih);

#endif
