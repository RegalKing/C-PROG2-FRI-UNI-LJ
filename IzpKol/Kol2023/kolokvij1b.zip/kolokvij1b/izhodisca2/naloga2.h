
#ifndef _NALOGA2_H
#define _NALOGA2_H

char** naSredino(char** nizi, int ciljnaDolzina);

#endif
