
/*
 * Va"sa re"sitev prve naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 1 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

int main() {
   
    int n;
    scanf("%d", &n);
    bool prva = false;

    char ch = getchar();

    // preberi prvi presledek
    ch = getchar();

    // prvi znak
    if (isalpha(ch))
    {
        ch = toupper(ch);
        prva = false;
    }

    while (ch != '\n')
    {
        if (isalpha(ch))
            if (prva)
            {
                prva = false;
                ch = toupper(ch);
            }
        if (!isalpha(ch))
            prva = true;

        putchar(ch);
        ch = getchar();
    }
    printf("\n");

    return 0;
}
