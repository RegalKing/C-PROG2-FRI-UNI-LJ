
/*
 * Va"sa re"sitev druge naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 2 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef unsigned char uchar;

uchar* preberi(char* imeDatoteke, int* sirina, int* visina, int* stBajtov) 
{
    FILE* fVhod = fopen(imeDatoteke, "r");
    
    char* visinaSirina = malloc(10 * sizeof(char));

    fscanf(fVhod, "%s", visinaSirina);
    fscanf


    fsanf(fVhod, "%s", )
    return NULL;
}

int sivina(uchar* pike, int sirina, int visina, int vrstica, int stolpec) {
    // popravite oz. dopolnite / modify and/or add ...
    return -1;
}

int main() {
    int sirina, visina, stBajtov;
    uchar* pike = preberi("b.ppm", &sirina, &visina, &stBajtov);

    printf("%d\n", stBajtov);
    for (int i = 0;  i < stBajtov;  i++) 
    {
        if (i > 0) 
            printf(" ");
        printf("%d", pike[i]);
    }

    exit(0);
    return 0;
}

