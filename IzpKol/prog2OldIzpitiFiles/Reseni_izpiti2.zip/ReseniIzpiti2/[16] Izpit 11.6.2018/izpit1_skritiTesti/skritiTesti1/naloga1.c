
/*
 * Va"sa re"sitev prve naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 1 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main() {
    int n;
    scanf("%d", &n);
    int* visine = (int *) malloc(n * sizeof(int));
    for (int i = 0; i < n; i++)
        scanf("%d", &visine[i]);
    
    int stOseb = 1;
    int max = visine[n - 1];
   // printf("%d\n", max);

    for (int i = n - 1; i >= 0; i--)
    {
        if (visine[i - 1] > visine[i])
        {
            if (visine[i - 1] >= max)
            {
                max = visine[i - 1];
                //printf("%d \n", max);
                stOseb++;
            }
        }
        
    }
    printf("%d\n", stOseb);
    return 0;
}
