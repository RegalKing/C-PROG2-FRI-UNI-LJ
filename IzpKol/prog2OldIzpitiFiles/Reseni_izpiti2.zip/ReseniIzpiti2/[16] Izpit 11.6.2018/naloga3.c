/*
Mnozico stevil razdeli v 2 podmnozici tako, da je absolutna vrednost
razlike med vsoto stevil v prvi podmnozici in vsoto stevil v drugi podmnozici najmanjsa
mozna.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


int min(int prvi, int drugi) 
{
    if (prvi < drugi)
        return prvi;
    else 
        return drugi;
} 

// minimum sum 
int findMinRec(int* array, int i, int currentSum, int sumTotal) 
{ 
    if (i == 0) 
        return abs((sumTotal - currentSum) - currentSum); 
  
    // arr[i]: include, exclude
    return min(findMinRec(array, i - 1, currentSum + array[i - 1], sumTotal), findMinRec(array, i - 1, currentSum, sumTotal)); 
}
  
int main() 
{
    int n, sumTotal = 0;
    scanf("%d", &n);
    int array[n];

    for (int i = 0; i < n; i++) 
    {
        scanf("%d", &array[i]);
        sumTotal += array[i];
    }
    
    printf("%d\n", findMinRec(array, n, 0, sumTotal));
    
    return 0;
}


