
/*
 * Va"sa re"sitev druge naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 2 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

#include "naloga2.h"

uchar* preberi(char* imeDatoteke, int* sirina, int* visina, int* stBajtov) 
{
	FILE* vhod = fopen(imeDatoteke, "r");

	char* garbage = malloc(10 * sizeof(char));
    fscanf(vhod, "%s", garbage);
	fscanf(vhod, "%d %d", sirina, visina);
	fscanf(vhod, "%s", garbage);
	free(garbage);

	*stBajtov = 3 * *visina * *sirina;

	uchar* tabela = malloc(*stBajtov * sizeof(uchar));
	
	unsigned char r;
	fscanf(vhod, "%c", &r);

	int index = 0;
	
	for (int v = 0; v < *visina; v++) 
	{
		for (int k = 0; k < *sirina; k++) 
		{
			for (int i = 0; i < 3; i++) 
			{
				fscanf(vhod, "%c", &r);
				*(tabela + index) = r;
				index++;
			}
		}
	}
	
	fclose(vhod);
	
	return tabela;
}

int sivina(uchar* pike, int sirina, int visina, int vrstica, int stolpec) 
{
	int i = (vrstica * sirina + stolpec) * 3;
	uchar r = *(pike + i);
	uchar g = *(pike + i + 1);
	uchar b = *(pike + i + 2);
	return (r + g + b) / 3;
}

int main() 
{
    // po "zelji dodajte kodo za ro"cno testiranje ...
    // add manual testing code if desired ...
    return 0;
}
