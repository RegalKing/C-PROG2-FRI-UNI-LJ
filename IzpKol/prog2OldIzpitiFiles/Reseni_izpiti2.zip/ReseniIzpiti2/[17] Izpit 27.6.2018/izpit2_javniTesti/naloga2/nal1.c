
/*
 * Va"sa re"sitev druge naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 2 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

#include "naloga2.h"

Vozlisce* vstaviUrejeno(Vozlisce* zacetek, int element) 
{
    if (zacetek == NULL) 
    {
		zacetek = malloc(sizeof(Vozlisce));
		zacetek->podatek = element;
		zacetek->n = NULL;
		zacetek->nn = NULL;
		return zacetek;
	} else if (element <= zacetek->podatek) 
    {
		Vozlisce *v = malloc(sizeof(Vozlisce));
		v->podatek = zacetek->podatek;
		v->n = zacetek->n;
		v->nn = zacetek->nn;
		
		zacetek->podatek = element;
		zacetek->n = v;
		zacetek->nn = v->n;	
		return zacetek;
	} else if (zacetek->n == NULL) 
    {
		Vozlisce *v = malloc(sizeof(Vozlisce));
		v->podatek = element;
		v->n = NULL;
		v->nn = NULL;
		zacetek->n = v;
		return zacetek;
	}
	
	Vozlisce *v = vstaviUrejeno(zacetek->n, element);
    zacetek->nn = v->n;
    
    return zacetek;
}

void izpisi(Vozlisce* zacetek) {
    Vozlisce* p = zacetek;
    while (p != NULL) {
        if (p != zacetek) {
            printf(" -> ");
        }
        printf("%d", p->podatek);
        p = p->n;
    }
    printf(" | ");

    Vozlisce* pp = zacetek;
    while (pp != NULL) {
        if (pp != zacetek) {
            printf(" ->-> ");
        }
        printf("%d", pp->podatek);
        pp = pp->nn;
    }
    printf(" | ");
    if (zacetek != NULL) {
        Vozlisce* pp = zacetek->n;
        while (pp != NULL) {
            if (pp != zacetek->n) {
                printf(" ->-> ");
            }
            printf("%d", pp->podatek);
            pp = pp->nn;
        }
    }
    printf("\n");
}

Vozlisce* zgradiSeznam() {
    Vozlisce* v001 = malloc(sizeof(Vozlisce));
    Vozlisce* v002 = malloc(sizeof(Vozlisce));
    Vozlisce* v003 = malloc(sizeof(Vozlisce));
    Vozlisce* v004 = malloc(sizeof(Vozlisce));
    v001->podatek = 10;
    v002->podatek = 20;
    v003->podatek = 30;
    v004->podatek = 40;
    v001->n = v002;
    v002->n = v003;
    v003->n = v004;
    v004->n = NULL;
    v001->nn = v003;
    v002->nn = v004;
    v003->nn = NULL;
    v004->nn = NULL;
    return v001;
}

void pocisti(Vozlisce* zacetek) {
    if (zacetek != NULL) {
        pocisti(zacetek->n);
        free(zacetek);
    }
}

int main() {
    Vozlisce* zacetek = zgradiSeznam();

    printf("PREJ:   ");
    izpisi(zacetek);

    printf("VSTAVI: 25\n");
    zacetek = vstaviUrejeno(zacetek, 25);

    printf("POTEM:  ");
    izpisi(zacetek);

    pocisti(zacetek);
    exit(0);
    return 0;
}
