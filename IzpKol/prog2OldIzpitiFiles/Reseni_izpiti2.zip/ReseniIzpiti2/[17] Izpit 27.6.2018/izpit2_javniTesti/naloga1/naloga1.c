
/*
 * Va"sa re"sitev prve naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 1 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

// 60%

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

bool plusPrvi = true;

int main() 
{
    char ch;
    int n;
    scanf("%d", &n);

    int stPlusov = 0;
    int razdalje = 0;

    // presledek
    ch = getchar();

    char* buffer = (char *) malloc(n * sizeof(char));

    for (int i = 0; (ch = getchar()) != EOF; i++)
    {
        if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\0')
            continue;
        buffer[i] = ch;
        if (ch == '+')
            stPlusov++;
    }

    char* tPlus = (char *) calloc(stPlusov, sizeof(int));
    int j = 0;
    for (int i = 0; i < n; i++)
    {
        if (buffer[i] == '+')
        {
            tPlus[j] = i;
            j++;
        }
    }

    // for (int i = 0; i < stPlusov; i++)
    //     printf("%d \n", tPlus[i]);
    
    for (int i = 0; i < stPlusov - 1; i++)
        razdalje += (tPlus[i + 1] - tPlus[i]);

   printf("%d\n", razdalje / (stPlusov - 1));
   //printf(" %d\n", plus);

    return 0;

}