/*
Zaporedje n pozitivnih stevil.
Izpise, na koliko nacinov lahko izberemo k indeksov, tako da bo vsota
elementov zaporedja na teh indeksih enaka natanko v.

n = 8, k = 3, v = 10
0. 3 
1. 7 
2. 2 
3. 4 
4. 5 
5. 1 
6. 5 
7. 9

V tem primeru lahko indekse izberemo na 5 nacinov:
{0, 2, 4} {3 + 2 + 5 = 10}
{0, 2, 6} {3 + 2 + 5 = 10}
{1, 2, 5} {7 + 2 + 1 = 10}
{3, 4, 5} {4 + 5 + 1 = 10}
{3, 5, 6} {4 + 1 + 5 = 10}
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int numWays(int n, int k, int v, int* array, int numIncluded, int currentSum, int currentIndex)
{
    if (currentSum == v && numIncluded == k) 
        return 1;
    if (currentSum > v || numIncluded > k || currentIndex > n) 
        return 0;
    return numWays(n, k, v, array, numIncluded + 1, currentSum + array[currentIndex], currentIndex + 1) + numWays(n, k, v, array, numIncluded, currentSum, currentIndex + 1);
}

int main() 
{
    int n, k, v;
    scanf("%d %d %d", &n, &k, &v);
    int array[n];
    for (int i = 0; i < n; i++)
        scanf("%d", &array[i]);
    printf("%d\n", numWays(n, k, v, array, 0, 0, 0));
    return 0;
}
