
typedef struct _Vozlisce {
    struct _Vozlisce* naslednje;
} Vozlisce;

int steviloElementov(Vozlisce* p);
