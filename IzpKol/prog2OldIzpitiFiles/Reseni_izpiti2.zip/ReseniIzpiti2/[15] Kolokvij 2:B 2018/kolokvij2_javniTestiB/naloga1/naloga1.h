
typedef struct _Vozlisce {
    struct _Vozlisce* naslednje;
} Vozlisce;

int razdalja(Vozlisce* p, Vozlisce* q);
