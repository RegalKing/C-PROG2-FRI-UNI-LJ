
/*
 * Va"sa re"sitev druge naloge --- datoteko dopolnite in jo oddajte na spletno u"cilnico!
 *
 * Your solution to task 2 --- complete the file and submit it to U"cilnica!
 *
 * V naslednjo vrstico vpi"site va"so vpisno "stevilko / Enter your student ID number in the next line:
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int stRazporeditev(int prejsni, int trenutni, int ostaloStolov, int ostaloLjudi)
{
    if ((prejsni == 1 && prejsni == trenutni) || ostaloStolov < 0 || ostaloLjudi < 0)
        return 0;
    if (ostaloStolov == 0 && ostaloLjudi == 0)
        return 1;
    return stRazporeditev(trenutni, 1, ostaloStolov - 1, ostaloLjudi - 1) + stRazporeditev(trenutni, 0, ostaloStolov - 1, ostaloLjudi);
}

int main()
{
    int stSedezev, stLjudi;
    scanf("%d %d", &stSedezev, &stLjudi);

    printf("%d\n", stRazporeditev(0, 0, stSedezev, stLjudi));

    return 0;
}