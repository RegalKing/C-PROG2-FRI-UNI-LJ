
#ifndef _NALOGA1_H
#define _NALOGA1_H

int sestEj(char* niz);

#endif
