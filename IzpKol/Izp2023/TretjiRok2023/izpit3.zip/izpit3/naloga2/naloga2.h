
#ifndef _NALOGA2_H
#define _NALOGA2_H

int** zmehcaj(int** slika, int n, int m, int d);

#endif
